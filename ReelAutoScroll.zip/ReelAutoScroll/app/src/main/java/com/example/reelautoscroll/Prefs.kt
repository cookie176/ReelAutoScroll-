package com.example.reelautoscroll

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
    fun fallbackSeconds(c: Context) = sp(c).getInt("fallback", 20)
    fun setFallbackSeconds(c: Context, v: Int) = sp(c).edit().putInt("fallback", v).apply()
}
