package com.example.reelautoscroll

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "Reel AutoScroll"; textSize = 26f
        })
        col.addView(TextView(this).apply {
            text = "\n1. Tap the button below and enable \"Reel AutoScroll\" under Accessibility.\n" +
                "2. Open Instagram Reels or YouTube Shorts. After a video plays once, it swipes to the next one."
        })
        col.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        col.addView(Switch(this).apply {
            text = "Auto-scroll on"
            isChecked = Prefs.enabled(this@MainActivity)
            setPadding(0, pad, 0, pad)
            setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this@MainActivity, v) }
        })

        val label = TextView(this).apply {
            text = "Fallback timer: ${Prefs.fallbackSeconds(this@MainActivity)}s"
        }
        col.addView(label)
        col.addView(SeekBar(this).apply {
            max = 55
            progress = Prefs.fallbackSeconds(this@MainActivity) - 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setFallbackSeconds(this@MainActivity, p + 5)
                    label.text = "Fallback timer: ${p + 5}s"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(TextView(this).apply {
            text = "Used only if the app doesn't expose a video progress bar."
            textSize = 12f
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
