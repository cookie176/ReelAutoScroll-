package com.example.reelautoscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoScrollService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val targets = setOf("com.instagram.android", "com.google.android.youtube")
    private var lastScrollAt = 0L
    private var lastProgress = -1f

    private val ticker = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) {}
            handler.postDelayed(this, 400)
        }
    }

    override fun onServiceConnected() {
        handler.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()
        if (root == null || pkg !in targets || !Prefs.enabled(this)) {
            lastProgress = -1f
            lastScrollAt = now
            return
        }
        if (now - lastScrollAt < 1500) return

        val p = findProgress(root)
        if (p != null) {
            // Progress bar found: a big drop after being near the end means the video looped.
            if (lastProgress > 0.8f && p < lastProgress - 0.5f) {
                swipeNext(now)
                return
            }
            lastProgress = p
        } else if (now - lastScrollAt > Prefs.fallbackSeconds(this) * 1000L) {
            // No progress bar exposed: fall back to a fixed timer.
            swipeNext(now)
        }
    }

    private fun findProgress(node: AccessibilityNodeInfo?): Float? {
        if (node == null) return null
        val info = node.rangeInfo
        if (info != null && info.max > info.min && node.isVisibleToUser) {
            return (info.current - info.min) / (info.max - info.min)
        }
        for (i in 0 until node.childCount) {
            val r = findProgress(node.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun swipeNext(now: Long) {
        lastScrollAt = now
        lastProgress = -1f
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, m.heightPixels * 0.75f)
            lineTo(x, m.heightPixels * 0.25f)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 250)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
